// ==============================================
// CONTROLE DO MENU LATERAL (SIDEBAR)

const { type } = require("firebase/firestore/pipelines");

// ==============================================
const btnMenu = document.getElementById('btnMenu');
const btnFechar = document.getElementById('btnFechar');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');
const heroBanner = document.getElementById('heroBanner');
const WHATSAPP_NUMBER = "5543991191307";

if (btnMenu) {
    btnMenu.addEventListener('click', () => {
        sidebar.classList.add('active');
        overlay.classList.add('active');
    });
}

if (btnFechar) {
    btnFechar.addEventListener('click', () => {
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
    });
}

if (overlay) {
    overlay.addEventListener('click', () => {
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
    });
}

// Banner com efeito de Scroll
if (heroBanner) {
    window.addEventListener('scroll', () => {
        if (window.scrollY > 80) {
            heroBanner.classList.add('shrink');
        } else {
            heroBanner.classList.remove('shrink');
        }
    });
}

// ==============================================
// BANCO DE DADOS DOS PRODUTOS & EXIBIÇÃO DINÂMICA
// ==============================================
const databaseProdutos = {
    "desktop-rtx4090": {
        badge: "DESKTOP GAMER",
        titulo: "PC Gamer Ultimate Core i9 / RTX 4090",
        preco: "R$ 18.999,00",
        imagem: "./public/img/destaque.jpeg",
        specs: [
            "<strong>Processador:</strong> Intel Core i9-14900K 5.8GHz",
            "<strong>Placa de Vídeo:</strong> NVIDIA GeForce RTX 4090 24GB GDDR6X",
            "<strong>Memória RAM:</strong> 64GB DDR5 6000MHz RGB",
            "<strong>Armazenamento:</strong> SSD 2TB NVMe M.2 Gen4 (7400MB/s)",
            "<strong>Refrigeração:</strong> Water Cooler 360mm ARGB",
            "<strong>Fonte:</strong> 1000W 80 Plus Gold Modular",
            "<strong>Garantia:</strong> 12 Meses (Suporte Técnico Pro)"
        ]
    },
    "notebook-rtx4080": {
        badge: "NOTEBOOK GAMER & WORKSTATION",
        titulo: "Notebook TechPro 16\" OLED",
        preco: "R$ 14.499,00",
        imagem: "./public/img/destaque.jpeg",
        specs: [
            "<strong>Processador:</strong> AMD Ryzen 9 7945HX 5.4GHz (16 Cores)",
            "<strong>Placa de Vídeo:</strong> NVIDIA GeForce RTX 4080 Laptop 12GB",
            "<strong>Tela:</strong> 16\" OLED 2.5K (2560x1600) 240Hz 100% DCI-P3",
            "<strong>Memória RAM:</strong> 32GB DDR5 5600MHz",
            "<strong>Armazenamento:</strong> SSD 1TB NVMe M.2 Gen4",
            "<strong>Bateria:</strong> 99.9Whr com Carregamento Rápido (240W)",
            "<strong>Garantia:</strong> 12 Meses (Garantia Premium On-site)"
        ]
    },
    "workstation-pro": {
        badge: "WORKSTATION PROFISSIONAL",
        titulo: "Workstation Threadripper PRO",
        preco: "R$ 32.000,00",
        imagem: "./public/img/destaque.jpeg",
        specs: [
            "<strong>Processador:</strong> AMD Ryzen Threadripper PRO 7975WX (32 Cores / 64 Threads)",
            "<strong>Placa de Vídeo:</strong> NVIDIA RTX 6000 Ada Generation 48GB ECC",
            "<strong>Memória RAM:</strong> 128GB DDR5 ECC Registered (Quad-Channel)",
            "<strong>Armazenamento:</strong> Dual SSD 4TB NVMe M.2 Gen4 em RAID 0 (8TB Total)",
            "<strong>Placa-Mãe:</strong> WRX90 Workstation Chipset com Wi-Fi 6E / Dual 10GbE",
            "<strong>Fonte:</strong> 1600W 80 Plus Titanium",
            "<strong>Garantia:</strong> 24 Meses (Atendimento Prioritário Pro)"
        ]
    }
};

// Renderiza o produto correto na página produtos.html
const containerProduto = document.getElementById('selected-product-container');

if (containerProduto) {
    // Pega o ID passado na URL (ex: ?id=notebook-rtx4080)
    const urlParams = new URLSearchParams(window.location.search);
    let idProduto = urlParams.get('id');

    // Se o usuário acessar produtos.html direto sem ID, exibe o primeiro produto por padrão
    if (!idProduto || !databaseProdutos[idProduto]) {
        idProduto = "desktop-rtx4090";
    }

    const produto = databaseProdutos[idProduto];

    // Monta a lista de especificações em HTML
    const specsHTML = produto.specs.map(item => `<li>${item}</li>`).join('');

    // Injeta o produto selecionado na tela
    containerProduto.innerHTML = `
        <section class="product-detail-container">
            <div class="product-gallery">
                <img src="${produto.imagem}" alt="${produto.titulo}" class="main-product-img">
            </div>

            <div class="product-info-box">
                <span class="product-badge">${produto.badge}</span>
                <h2>${produto.titulo}</h2>
                <div class="product-price-tag">${produto.preco}</div>

                <div class="specs-accordion">
                    <h3>⚙️ Ficha Técnica do Equipamento</h3>
                    <ul class="specs-list">
                        ${specsHTML}
                    </ul>
                </div>

                <button class="btn-add-cart">🛒 Adicionar ao Carrinho</button>
            </div>
        </section>
    `;
}

function toggleChat() {
    const container = document.getElementById('chat-container');
    container.classList.toggle('hidden');
}

// Alternar entre as Abas (IA x Humano)
function switchTab(tab) {
    const btnAi = document.getElementById('tab-btn-ai');
    const btnHuman = document.getElementById('tab-btn-human');
    const contentAi = document.getElementById('tab-content-ai');
    const contentHuman = document.getElementById('tab-content-human');

    if (tab === 'ai') {
        btnAi.classList.add('active');
        btnHuman.classList.remove('active');
        contentAi.classList.add('active');
        contentHuman.classList.remove('active');
    } else {
        btnHuman.classList.add('active');
        btnAi.classList.remove('active');
        contentHuman.classList.add('active');
        contentAi.classList.remove('active');
    }
}

// Abrir conversa no WhatsApp
function openWhatsApp() {
    const message = encodeURIComponent("Olá! Vim através do site e gostaria de falar com um atendente.");
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, '_blank');
}

// Tratar tecla ENTER no campo de input
function handleKeyPress(event, type) {
    if (event.key === 'Enter') {
        sendMessage(type);
    }
}

// --- ENVIO E PROCESSAMENTO DE MENSAGENS ---

async function sendMessage(type) {
    const inputID = type === 'ai' ? 'user-input-ai' : 'user-input-human';
    const messagesAreaId = type === 'ai' ? 'chat-messages-ai' : 'chat-messages-human';
    
    const inputElement = document.getElementById(inputID);
    const messagesArea = document.getElementById(messagesAreaId);
    const text = inputElement.value.trim();

    if (!text) return;

    appendMessage(messagesArea, text, 'user-msg');
    inputElement.value = '';
    
    if (type === 'ai') {
        showTyping(true);

        try {

            const response = await fetch('http://localhost:5000/api/chat-ai', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ message: text})
            });

            const data = await response.json();
            showTyping(false);

            if (data.response) {
                appendMessage(messagesArea, data.response, 'system-msg');
            } else {
                appendMessage(messagesArea, "Ocorreu um erro ao processar sua pergunta.")
            }
        } catch (error) {
            showTyping(false);
            console.error('Erro de conexão com a IA', error);
            appendMessage(messagesArea, "Não foi possível conectar-se com a IA. Nossa equipe está cuidando do caso", 'system-msg');
        }

    } else {

        setTimeout(() => {
            appendMessage(messagesArea, "Sua Mensagem foi enviada a nossa equipe, em instantes responderemos.", 'system-msg');
        }, 800);
    }
}

// Adicionar elemento visual de mensagem no chat
function appendMessage(container, text, className) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', className);
    messageDiv.textContent = text;
    container.appendChild(messageDiv);
    
    // Rolar scroll para a mensagem mais recente
    container.scrollTop = container.scrollHeight;
}

// Exibir/Ocultar o indicador de digitação da IA
function showTyping(show) {
    const indicator = document.getElementById('typing-indicator');
    if (show) {
        indicator.classList.remove('hidden');
    } else {
        indicator.classList.add('hidden');
    }
}