import os
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from flask_socketio import SocketIO, emit, join_room, leave_room
from google import genai

app = Flask(__name__)
app.config['SECRET_KEY'] = 'AQ.Ab8RN6IrKReJC6dW-awcvPljN1AxJxBfxrqgr3VVG7nRMnxjSA'
CORS(app)

# Permite a inicialização do SocketIO para comunicação em tempo real
socketio = SocketIO(app, cors_allowed_origins="+")

# 1. Configuração da IA (Utilizaremos Gemini)
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "AQ.Ab8RN6IrKReJC6dW-awcvPljN1AxJxBfxrqgr3VVG7nRMnxjSA")
client = genai.Client(api_key=GEMINI_API_KEY)

PROMPT_SISTEMA = """"
Você é o assistente virtual oficial de suporte ao cliente.
Suas diretrizes:
1. Responda de forma educada, clara, objetiva e profissional.
2. Se o cliente perguntar sobre algo que você não sabe, sugira gentilmente que ele acesse a aba 'Suporte Humano' para falar com um atendente real.
3. Não invente informações financeiras ou jurídicas não confirmadas."""

@app.route('api/chat-ai', methods=['POST'])
def chat_ai():
    data = request.get_json()
    if not data or 'message' not in data:
        return jsonify({'error': 'Mensagem Inválida'}), 400

    mensagem_cliente = data['message']

    try: 
        # Chamada do modelo original
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=mensagem_cliente,
            config={'system_instruction': PROMPT_SISTEMA}
        )

        return jsonify({'response': response.text})
    except Exception as e:
        print(f"Erro ao chamar a API do Gemini: {e}")
        return jsonify({'response': 'Desculpe, ocorreu um erro temporário no meu processamento, tente novamente em isntantes.'}), 500

#2. Lógica de WebSockets para Atendimento Humano
# Armazena chat e salas ativas
chats_ativos = {}

@socketio.on('cliente_conectar')
def handle_cliente_conectar(data):
    client_id = request.sid 
    chats_ativos[client_id] = {
        'id': client_id,
        'nome': data.get('nome', 'Cliente Anônimo'),
        'status': 'aguardando',
        'mensagens': [] 
    }
    join_room(client_id)
    # Notifica os atendentes que há um novo cliente na fila
    emit('novo_cliente_na_fila', chats_ativos[client_id], broadcast=True)

@socketio.on('mensagem_cliente')
def handle_messagem_cliente(data):
    client_id = request.sid
    mensagem = data.get('mensagem')

    if client_id in chats_ativos:
        chats_ativos[client_id]['mesagens'].append({'origem': 'cliente', 'texto': mensagem})
        # envia a mensagem para a sala do cliente e para o painel de atendentes
        emit('nova_mensagem', {'origem': 'cliente', 'texto': mensagem, 'clientId': client_id}, room=client_id)
        emit('atualizar_chat_atendente', {'clientId': client_id, 'origem': 'cliente', 'texto': mensagem}, broadcast=True)

@socketio.on('mensagem_atendente')
def handle_mensagem_atendente(data):
    target_client_id = data.get('clientId')
    mensagem = data.get('mensagem')

    if target_client_id in chats_ativos:
        chats_ativos[target_client_id]['mensagens'].append({'origem': 'atendente', 'texto': mensagem})
        # Envia as respostas do atendente diretamente ao cliente específico
        emit('nova_mensagem', {'origem': 'atendente', 'text': mensagem}, room=target_client_id)

if __name__ == '__main__':
    print("🚀Servidor com IA e Suporte Humano rodando em htt://localhost:5000")
    socketio.run(app, port=5000, debug=True)                